#!/usr/bin/env python3

import os


def main():
    cwd = os.getcwd()
    print(cwd)
    a = 10
    b = 30
    return print(a + b)


if __name__ == '__main__':
    main()
